package com.devblogs.spring.beans;

public interface MyBean {
	public String getMessage();
}